import sys
from my_project.crew import AutomationAgent
from datetime import datetime

def run():
    """
    Run the crew.
    """
    inputs = {
        # 'query': 'genrate the report on the india it industry',
        'query': "generate a report on samsung phone indusrty and send as body email to emails which are provided in csv file with subject test and with attachment picture",
        'file_path':'S:\AffyCloud\Crew AI\my_project\PhotoRoom-20230811_172454.png',  # Optional file path for attachment
        'csv_file':'S:\AffyCloud\Crew AI\my_project\Book1.csv',  # Optional CSV file path for email
        'date': datetime.now().strftime('%Y-%m-%d')
    }
    AutomationAgent().crew().kickoff(inputs=inputs)


# send an email to sk9893836@gmail.com with subject "Hello" and message "Hope youre doing well



